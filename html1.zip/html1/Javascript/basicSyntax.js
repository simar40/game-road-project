window.addEventListener("load",initEvents);
function initEvents() {
    console.log("Binding function");
    document.getElementById("btn").addEventListener("click",showname);
}

function showname() {
    console.log("Function called")
    var username = document.getElementById("name").value;
    document.getElementById("result").innerHTML = username;
}