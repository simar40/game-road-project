window.addEventListener("load",initEvents);

var firstNo;
var secondNo;
var result = 0;

function initEvents() {
    firstNo = document.getElementById("first");
    secondNo = document.getElementById("second");
    button = document.getElementsByTagName("button");

    for(var i=0;i<button.length;i++)
    {
        button[i].addEventListener("click",calc);
    }
}

function calc(evt) {
    var opr = evt.srcElement.innerHTML;
    var expression = firstNo.value + opr + secondNo.value;
    result = eval(expression);
    document.getElementById("result").innerHTML = result;
}