window.addEventListener("load", initEvents);

var username;
var usermail;

function initEvents()
{
    username = document.querySelector("#username");
    usermail = document.querySelector("#usermail");
    span = document.querySelectorAll("span");
    username.addEventListener("blur",validatename);
    usermail.addEventListener("keyup",validatemail);
}

function validatename()
{
    var text = username.value;
    text = text.trim();
    blankCheck(text,0);
}

function validatemail()
{
    var text = usermail.value;
    text = text.trim();
    blankCheck(text,1);
    var pattern = /([a-z][0-9]\w+[@]\w+[.]+[a-z]{2,3}$)/;
    var valid = pattern.test(text);
    console.log(valid);
    if(valid)
    {
        span[1].innerHTML = 'Valid Email';
    }
    else {
        span[1].innerHTML = 'Not Valid Email';
    }
}

function blankCheck(text,id)
{
    text = text.trim();
    if(text.length == 0)
    {
        span[id].innerHTML = "Enter valid name";
    }
    else
    {
        span[id].innerHTML = "";
    }
}
