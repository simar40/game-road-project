import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.lang.Math;

public class BinaryTreeUse {
	
	public static BinaryTreeNode<Integer> levelWiseInput(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter value of root data :");
		int rootData = s.nextInt();
		
		if(rootData == -1) {
			return null;
		}
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(rootData);
		Queue<BinaryTreeNode<Integer>> pendingChildren = new LinkedList<BinaryTreeNode<Integer>>();
		pendingChildren.add(root);
		
		while(!pendingChildren.isEmpty()) {
			BinaryTreeNode<Integer> front = pendingChildren.poll();
			System.out.println("Enter left child of " + front.data);
			int left = s.nextInt();
			if(left != -1) {
				BinaryTreeNode<Integer> leftChild = new BinaryTreeNode<Integer>(left);
				front.left = leftChild;
				pendingChildren.add(leftChild);
			}
			
			System.out.println("Enter right child of " + front.data);
			int right = s.nextInt();
			if(right != -1) {
				BinaryTreeNode<Integer> rightChild = new BinaryTreeNode<Integer>(right);
				front.right = rightChild;
				pendingChildren.add(rightChild);
			}
		}
		return root;
	}
	
	public static void printLevelWise(BinaryTreeNode<Integer> root) {
		if(root == null){
            return;
        }
        Queue<BinaryTreeNode<Integer>> pendingNodes = new LinkedList<BinaryTreeNode<Integer>> ();
        pendingNodes.add(root);
        
        while(!pendingNodes.isEmpty()){
            BinaryTreeNode<Integer> front = pendingNodes.remove();
            System.out.print(front.data + ":L:");
            if(front.left != null){
                System.out.print(front.left.data + ",R:");
                pendingNodes.add(front.left);
            }
            else{
                System.out.print("-1,R:");
            }
            
            if(front.right != null){
                System.out.print(front.right.data);
                pendingNodes.add(front.right);
            }
            else{
                System.out.print("-1");
            }
            System.out.println();
        }
	}
	
	public static BinaryTreeNode<Integer> takeInputBetter(boolean isRoot, int parentData, boolean isLeft){
		if(isRoot) {
			System.out.println("Enter value of root");
		}
		else {
			if(isLeft) {
				System.out.println("Enter value of Left child of " + parentData);
			}
			else {
				System.out.println("Enter value of Right child of " + parentData);
			}
		}
		Scanner s = new Scanner(System.in);
		int rootData = s.nextInt();
		if(rootData == -1) {
			return null;
		}
		
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(rootData);
		BinaryTreeNode<Integer> LeftChild = takeInputBetter(false,rootData,true);
		BinaryTreeNode<Integer> RightChild = takeInputBetter(false,rootData,false);
		root.left = LeftChild;
		root.right = RightChild;
		return root;
	}
	
/*	A binary tree is called Balanced if The absolute difference of heights of left
    and right subtrees at any node is less than 1. 
	
  	Time complexity of this function in worst case will be n^2 and in best case of a
	balanced tree will be nlogn
*/
	public static boolean isBalanced(BinaryTreeNode<Integer> root) {
		if(root == null) {
			return true;
		}
		int leftHeight = Height(root.left);
		int rightHeight = Height(root.right);
		if(Math.abs(leftHeight - rightHeight) > 1) {
			return false;
		}
		boolean isLeftBalanced = isBalanced(root.left);
		boolean isRightBalanced = isBalanced(root.right);
		return isLeftBalanced && isRightBalanced;
	}
	
	public static BalancedTreeReturn isBalancedBetter(BinaryTreeNode<Integer> root) {
		if(root == null) {
			int height = 0;
			boolean isBal = true;
			BalancedTreeReturn ans = new BalancedTreeReturn();
			ans.height = height;
			ans.isBalanced = isBal;
			return ans;
		}
		BalancedTreeReturn leftOutput = isBalancedBetter(root.left);
		BalancedTreeReturn rightOutput = isBalancedBetter(root.right);
		int height = 1 + Math.max(leftOutput.height, rightOutput.height);
		boolean isBal = true;
		
		if(Math.abs(leftOutput.height - rightOutput.height)>1) {
			isBal = false;
		}
		
		if(!leftOutput.isBalanced || !rightOutput.isBalanced) {
			isBal = false;
		}
		BalancedTreeReturn result = new BalancedTreeReturn();
		result.height = height;
		result.isBalanced = isBal;
		return result;
	}

	public static int Height(BinaryTreeNode<Integer> root) {
		if(root == null) {
			return 0;
		}
		int leftHeight = Height(root.left);
		int rightHeight = Height(root.right);
		return 1+Math.max(leftHeight,rightHeight);
	}

	public static BinaryTreeNode<Integer> takeInput(){
		System.out.println("Enter value of root");
		Scanner s = new Scanner(System.in);
		int rootData = s.nextInt();
		if(rootData == -1) {
			return null;
		}
		
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(rootData);
		BinaryTreeNode<Integer> LeftChild = takeInput();
		BinaryTreeNode<Integer> RightChild = takeInput();
		root.left = LeftChild;
		root.right = RightChild;
		return root;
	}
	
	public static void printTreeDetailed(BinaryTreeNode<Integer> root) {
		if(root == null) {
			return;
		}
		System.out.print(root.data + ":");
		if(root.left != null) {
			System.out.print("L" + root.left.data + ",");
		}
		if(root.right != null) {
			System.out.print("R" + root.right.data);
		}
		System.out.println();
		
		printTreeDetailed(root.left);
		printTreeDetailed(root.right);
	}
	
	public static void printTree(BinaryTreeNode<Integer> root) {
		if(root==null) {
			return;
		}
		System.out.println(root.data);
		printTree(root.left);
		printTree(root.right);
	}
	
	public static BinaryTreeNode<Integer> RemoveLeaves(BinaryTreeNode<Integer> root){
		if(root == null) {
			return null;
		}
		if(root.left == null && root.right == null) {
			return root;
		}
		root.left = RemoveLeaves(root.left);
		root.right = RemoveLeaves(root.right);
		return root;
	}
	
	public static void main(String[] args) {
//		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(1); 
//		BinaryTreeNode<Integer> rootLeft = new BinaryTreeNode<Integer>(2);
//		BinaryTreeNode<Integer> rootRight = new BinaryTreeNode<Integer>(3);
//		
//		root.left = rootLeft;
//		root.right = rootRight;
//		
//		BinaryTreeNode<Integer> TwoLeft = new BinaryTreeNode<Integer>(4);
//		BinaryTreeNode<Integer> ThreeRight = new BinaryTreeNode<Integer>(5);
//		rootLeft.left = TwoLeft;
//		rootRight.right = ThreeRight;
//		
//		printTree(root);
		BinaryTreeNode<Integer> root = levelWiseInput();
		printLevelWise(root);
		System.out.println(isBalancedBetter(root).isBalanced);
//		boolean result = isBalanced(root);
//		System.out.println(result);
//		printTreeDetailed(root);
	}

}
