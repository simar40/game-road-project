
public class BalancedTreeReturn {
	int height;
	boolean isBalanced;
}
