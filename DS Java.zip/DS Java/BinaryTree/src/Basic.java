/*
Binary tree is a tree kind of structure But in Binary tree, each node can have maximum 2
nodes further. 
* The main starting point node is called Root. 
* The Root node is also called parent node.
* The nodes attached to root nodes are called child nodes.
* The child nodes are called together as siblings.

 * A binary tree is called Balanced if The absolute difference of heights of left
   and right subtrees at any node is less than 1. 
*/
public class Basic {

}
