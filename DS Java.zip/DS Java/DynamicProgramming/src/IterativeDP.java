import java.util.Scanner;

/*
In iterative DP we use same storage as used in recursive problems but we also store base case
in storage and then iterate from the next index of base problem to the ans required in ques. 
Iterative approach is better in terms of space complexity, although in both the cases the
space complexity is of order O(N) but if input cases become of order >10^4 then it gives
stack overflow error in recursive case.
*/
public class IterativeDP {

	private static int fib(int n, int[] dp) {
		if(n==0 || n==1) {
			return n;
		}
		dp[0]=0;
		dp[1]=1;
		for(int i=2;i<=n;i++) {
			dp[i] = dp[i-1] + dp[i-2];
		}
		return dp[n];
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int[] dp = new int[n+1];
		for(int i=0;i<=n;i++) {
			dp[i] = -1;
		}
		System.out.println(fib(n,dp));
	}
}
