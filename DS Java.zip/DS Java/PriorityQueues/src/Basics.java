/*
 * In computer science, a priority queue is an abstract data type similar to a regular queue
   or stack data structure in which each element additionally has a "priority" associated
   with it. It is of 2 types :
   
   1.Min PQ : Element with min priority is removed first.
   2.Max PQ : Element with max priority is removed first.
   
   In PQ data is stored in form of heap memory. Heap follows following conditions : 
   1. It is a complete Binary tree(CBT).
   2. It follow Heap order property.
   
   CBT is a tree in which :
   1. All the levels must be completely filled except the last level.
   2. All the levels must be filled in left to right order manner.
   
   In heap, data is internally stored in form of array.
   1. If 'i' is index of parent data then left and right child will have index 2*i+1,2*i+2.
   2. If 'i' is index of child data the parent will have parent index as (i-1)/2.
   
   All operations are of order O(log n) in PQ.
   Heap order property is :
   1. Max Heap : In this priority of all parent nodes should be greater than its child nodes.
   				 The element with max priority is root.
   2. Min Heap : In this priority of all parent nodes should be less than its child nodes.
   				 The element with min priority is root.
*/
public class Basics {

}
