
public class PQuse {

	public static void main(String[] args) throws EmptyQueueException {
		PriorityQueue<String> pq = new PriorityQueue<>();
		pq.insert("Asd",125);
		pq.insert("fsafadf",52);
		pq.insert("lowest",15);
		pq.insert("dsafds",75);
		pq.insert("highest",250);
		while(!pq.isEmpty()) {
			System.out.println(pq.getMin());
			pq.removeMin();
		}
	}

}
