
public class EmptyQueueException extends Exception {

}
