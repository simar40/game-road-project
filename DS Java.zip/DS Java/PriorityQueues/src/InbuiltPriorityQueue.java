import java.util.PriorityQueue;
public class InbuiltPriorityQueue {

	public static void main(String[] args) {
		int[] arr = {1,31,43,2,4,65,3,87,9,98};
//		Inbuilt queue is of minimum queue.
		PriorityQueue<Integer> pq = new PriorityQueue<>();
		for(int i=0;i<arr.length;i++) {
			pq.add(arr[i]);
		}
		while(!pq.isEmpty()) {
			System.out.println(pq.peek());
//			poll() removes minimum/peek element from queue.
			pq.poll();
		}
	}
}
