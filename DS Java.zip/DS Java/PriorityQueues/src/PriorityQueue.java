import java.util.ArrayList;
public class PriorityQueue <T> {

	private ArrayList<Element<T>> heap;
	
	public PriorityQueue(){
		heap = new ArrayList<>();
	}
	
	public void insert(T value,int priority) {
		Element<T> e = new Element<>(value, priority);
		heap.add(e);
		int childIndex = heap.size()-1;
		int parentIndex = (childIndex - 1)/2;
		
		while(childIndex > 0) {
			if(heap.get(childIndex).priority < heap.get(parentIndex).priority) {
				Element<T> temp = heap.get(childIndex);
				heap.set(childIndex, heap.get(parentIndex));
				heap.set(parentIndex, temp);
				childIndex = parentIndex;
				parentIndex = (childIndex - 1)/2;
			}
			else {
				return;
			}
		}
	}
	
	public T removeMin() throws EmptyQueueException {
		if(isEmpty()) {
			throw new EmptyQueueException();
		}
		Element<T> removed = heap.get(0);
		T ans = heap.get(0).value;
		
		heap.set(0, heap.get(heap.size()-1));
		heap.remove(heap.size()-1);
		
		int parentIndex = 0;
		int leftChildIndex = 2*parentIndex + 1;
		int rightChildIndex = 2*parentIndex + 2;
		int minIndex = parentIndex;
		while(leftChildIndex < heap.size()) {
			if(heap.get(leftChildIndex).priority < heap.get(minIndex).priority) {
				minIndex = leftChildIndex;
			}

			if(rightChildIndex < heap.size() && heap.get(rightChildIndex).priority < heap.get(minIndex).priority) {
				minIndex = rightChildIndex;
			}
			
			if(minIndex == parentIndex) {
				break;
			}
			//MinIndex is storing value of element with minimum priority among L R and parent.
			//Swap parent and minIndex.
			Element<T> temp = heap.get(parentIndex);
			heap.set(parentIndex, heap.get(minIndex));
			heap.set(minIndex, temp);
			
			parentIndex = minIndex;
			leftChildIndex = parentIndex*2 + 1;
			rightChildIndex = parentIndex*2 + 2;
		}
		return ans;
	}
		
	public T getMin() throws EmptyQueueException {
		if(isEmpty()) {
			throw new EmptyQueueException();
		}
		return heap.get(0).value;
	}
	public int size() {
		return heap.size();
	}
	
	public boolean isEmpty() {
		return heap.size() == 0;
	}
}
