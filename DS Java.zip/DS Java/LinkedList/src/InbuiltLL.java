import java.util.LinkedList;
/*
This is an inbuilt linked list and it is doubly linked list. We do not have to create any 
class or function for this, it is already created and saved. 

Doubly linked list is a list in which all each element has access to its next as well as its
previous element. But last element points to null.

Circular linked list is a list in which last element points to first element. But to access
last element, temp=head
while(temp!=head){
	temp=temp.next;
}

Doubly circular linked list is a LL in which last element points to first element and first to
last also all elements point to next as well as previous element of linked list. In this head
has access to last element as well by using head.prev;
*/
public class InbuiltLL {

	public static void main(String[] args) {
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		System.out.println(list.size());
		list.add(2, 11);
		list.set(1, 14);
		list.addFirst(67);
		
		for(int i=0;i<list.size();i++) {
			System.out.print(list.get(i)+" ");
		}
	}

}
