/*
Linked list is a data structure where in which elements are connected to one another via
links. In arrays like elements are stored in sequence i.e. one after other in same order.
But in linked list, every element is stored where ever it finds suitable space. In fact,
it is not stored as element but i form of nodes.
 * Each element stored in linked list is called a Node.
 * The place where reference of first element is stored in list is called Head.
 * The last element stored is called Tail.
 * Each node contains the element to be stored and also address of the next node stored.
 * Last node contains NULL reference as there is no next element.
So in linked list each element contains reference to the next element and that's why we can
say that each element is linked to the next element and this is the reason why it is called
a Linked List.
*/

public class Basics{

}