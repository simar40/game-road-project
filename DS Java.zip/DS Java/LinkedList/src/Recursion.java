import java.util.Scanner;

class doubleNode{
	Node<Integer> head;
	Node<Integer> tail;
	doubleNode(){
		
	}
	doubleNode(Node<Integer> head, Node<Integer> tail){
		this.head=head;
		this.tail=tail;
	}
}

public class Recursion {

	public static void print(Node<Integer> head) {
		if(head==null) {
			return;
		}
		System.out.println(head.data);
		print(head.next);
	}
	
	public static Node<Integer> insertAtIndex(Node<Integer> head,int n,int i){
		if(head==null && i>0) {
			return head;
		}
		if(i==0) {
			Node<Integer> newHead=new Node<Integer>(n);
			newHead.next=head;
			return newHead;
		}
		else {
			head.next=insertAtIndex(head.next, n, i-1);
			return head;
		}
	}
	
	public static Node<Integer> insert(){
		Scanner s=new Scanner(System.in);
		int data=s.nextInt();
		Node<Integer> head = null,tail=null;
		while(data != -1) {
			Node <Integer> currentNode=new Node<>(data);
			if(head==null) {
				head=currentNode;
				tail=currentNode;
			}
			else {
				tail.next=currentNode;
				tail=currentNode;
			}
			data=s.nextInt();
		}
		return head;
	}
	
	public static doubleNode reverseBetterR(Node<Integer> head) {
		doubleNode ans;
		if(head==null || head.next==null) {
			ans=new doubleNode();
			ans.head=head;
			ans.tail=head;
			return ans;
		}
		
		else {
			doubleNode smallans = reverseBetterR(head.next);
			smallans.tail.next=head;
			head.next=null;
			ans=new doubleNode();
			ans.head=smallans.head;
			ans.tail=head;
			return ans;
		}
	}
	public static Node<Integer> reverseBetterHelper(Node<Integer> head) {
		doubleNode ans = reverseBetterR(head);
		return ans.head;
	}
	
	public static Node<Integer> reverseBest(Node<Integer> head){
		if(head==null || head.next==null) {
			return head;
		}
		else {
			Node<Integer> smallHead = reverseBest(head.next);
			Node<Integer> reverseTail = head.next;
			reverseTail.next=head;
			head.next=null;
			return smallHead;
		}
	}
	public static void main(String[] args) {
		Node<Integer> head=insert();
		Node<Integer> ans=reverseBest(head);
		print(ans);
	}

}
