import java.util.Scanner;

public class LinkedListUse {
	
	public static Node<Integer> CreateLinkedList(){
		Node<Integer> n1=new Node<>(10);
		Node<Integer> n2=new Node<>(20);
		Node<Integer> n3=new Node<>(30);
		n1.next=n2;
		n2.next=n3;
		return n1;
	}
	
	public static void printLinkedList(Node<Integer> Head) {
		Node<Integer> temp=Head;
		while(temp != null) {
			System.out.println(temp.data);
			temp=temp.next;
		}
	}
	
	public static void increment(Node<Integer> Head) {
		Node<Integer> temp=Head;
		while(temp!=null) {
			temp.data++;
			temp=temp.next;
		}
	}
	
	public static Node<Integer> insert(){
		Scanner s=new Scanner(System.in);
		int data=s.nextInt();
		Node<Integer> head = null,tail=null;
		while(data != -1) {
			Node <Integer> currentNode=new Node<>(data);
			if(head==null) {
				head=currentNode;
				tail=currentNode;
			}
			else {
			/*	Node<Integer> tail=head;
				while(tail.next != null) {
					tail=tail.next;
				}
			*/
				//THIS HAS TIME COMPLEIXTY OF N^2.
				//Now tail is pointing towards last node.
				//connect current to last node.
				tail.next=currentNode;
				tail=currentNode;
				//THIS HAS TIME COMPLEXITY OF N.
			}
			data=s.nextInt();
		}
		return head;
	}
	
	public static void main(String[] args) {
		Node <Integer> x = new Node<>(10);
		System.out.println(x.data);
		System.out.println(x.next);
		Node<Integer> ans = insert();//CreateLinkedList();
//		System.out.println(ans);
//		System.out.println(x);
		printLinkedList(ans);
		increment(ans);
		printLinkedList(ans);
	}

}
