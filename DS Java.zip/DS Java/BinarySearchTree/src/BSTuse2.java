
public class BSTuse2 {
	public static void main(String[] args) {
		BSTclass tree = new BSTclass();
		tree.insert(5);
		tree.insert(2);
		tree.insert(7);
		tree.insert(1);
		tree.insert(3);
		tree.insert(6);
		tree.insert(8);
		
		tree.printTree();
		System.out.println(tree.isPresent(5));
		System.out.println(tree.deleteData(8));
		tree.printTree();
	}
}
