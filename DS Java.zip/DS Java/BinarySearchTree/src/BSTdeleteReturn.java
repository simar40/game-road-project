
public class BSTdeleteReturn {
	boolean isDeleted;
	BinaryTreeNode<Integer> root;
	public BSTdeleteReturn(BinaryTreeNode<Integer> root,boolean isDeleted) {
		this.root = root;
		this.isDeleted = isDeleted;
	}
}
