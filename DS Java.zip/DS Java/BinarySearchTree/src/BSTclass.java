import java.util.ArrayList;

public class BSTclass {
	private BinaryTreeNode<Integer> root;
	private int size;

	public boolean isPresent(int n) {
		return isPresentHelper(root,n);
	}

	private static boolean isPresentHelper(BinaryTreeNode<Integer> node, int n) {
		if(node == null) {
			return false;
		}
		if(node.data == n) {
			return true;
		}
		if(node.data > n) {
			return isPresentHelper(node.left,n);
		}
		else {
			return isPresentHelper(node.right,n);
		}
	}

	public void insert(int x) {
		root = insertHelper(root,x);
		size++;
	}

	private static BinaryTreeNode<Integer> insertHelper(BinaryTreeNode<Integer> node, int x) {
		if(node == null) {
			BinaryTreeNode<Integer> newRoot = new BinaryTreeNode<Integer>(x);
			return newRoot;
		}
		if(node.data > x) {
			node.right = insertHelper(node.right, x);
		}
		else {
			node.left = insertHelper(node.left, x);
		}
		return node;
	}

	public boolean deleteData(int x) {
		BSTdeleteReturn ans = deleteHelper(root, x);
		root = ans.root;
		if(ans.isDeleted) {
			size--;
		}
		return ans.isDeleted;
	}

	private static int smallest(BinaryTreeNode<Integer> root) {
		if(root == null) {
			return Integer.MAX_VALUE;
		}
		int smallestLeft = smallest(root.left);
		int smallestRight = smallest(root.right);
		return Math.min(root.data, Math.max(smallestLeft,smallestRight));
	}

	private static BSTdeleteReturn deleteHelper(BinaryTreeNode<Integer> node, int x) {
		if(node == null) {
			return new BSTdeleteReturn(null, false);
		}

		if(node.data < x) {
			BSTdeleteReturn rightAns = deleteHelper(node.right, x);
			node.right = rightAns.root;
			rightAns.root = node;
			return rightAns;
		}

		else if(node.data > x) {
			BSTdeleteReturn leftAns = deleteHelper(node.left, x);
			node.left = leftAns.root;
			leftAns.root = node;
			return leftAns;
		}
		else {
			// 0 children
			if(node.left == null && node.right == null) {
				return new BSTdeleteReturn(null, true);
			}

			// Left child only
			else if(node.left != null && node.right == null) {
				return new BSTdeleteReturn(node.left, true);
			}

			// Right child only
			else if(node.right != null && node.left == null) {
				return new BSTdeleteReturn(node.right, true);
			}

			// Both left and right child present
			else {
				int rightMin = smallest(node.right);
				node.data = rightMin;			
				BSTdeleteReturn rightOutput = deleteHelper(node.right, rightMin);
				node.right = rightOutput.root;
				return new BSTdeleteReturn(node, true);
			}
		}
	}

	public int size() {
		return size;
	}
	public void printTree() {
		printTreeHelper(root);
	}

	private static void printTreeHelper(BinaryTreeNode<Integer> node) {
		if(node == null) {
			return;
		}
		System.out.print(node.data + ":");
		if(node.left != null) {
			System.out.print("L:" + node.left.data + ",");
		}
		if(node.right != null) {
			System.out.print("R:" + node.right.data);
		}
		System.out.println();
		printTreeHelper(node.left);
		printTreeHelper(node.right);
	}
}
