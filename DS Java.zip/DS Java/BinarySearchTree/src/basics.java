/*
A binary search tree is a tree that is sorted and it is much easier to find elements in it.
Sorted binary tree means all elements on left side of each node are smaller than center node
and all that are on right side are larger than center node. 

The time complexity to find an element in BST is log n in normal cases but in worst case it 
can be o(n).
*/
public class basics {

}
