
public class IsBSTreturn {
	int min;
	int max;
	boolean isBST;
	public IsBSTreturn(int min, int max, boolean isBST) {
		this.min = min;
		this.max = max;
		this.isBST = isBST;
	}
}
