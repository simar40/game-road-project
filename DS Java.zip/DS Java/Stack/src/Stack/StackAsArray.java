/*
Stack is DS in which element can only be added or deleted at the top most index. It follows
the principle of LIFO i.e. Last in first out. So the last element that is added is last to
be removed.
*/

package Stack;
//All these functions have time complexity of O(1) which is great and very fast.
public class StackAsArray {
	private int topIndex;
	private int data[];
	StackAsArray() {
		data = new int[10];
		topIndex = -1;
	}
	
	StackAsArray(int size) {
		data = new int[size];
		topIndex = -1;
	}
	
	public void push(int elem) {
		//Check if stack is full
		if(topIndex == data.length-1) {
			doubleCapacity();
		}
		data[++topIndex]=elem;
	}
	
	private void doubleCapacity() {
		int temp[] = data;
		data = new int[2*temp.length];
		for(int i=0;i<temp.length;i++) {
			data[i] = temp[i];
		}
	}

	public int pop() throws StackEmpty {
		if(topIndex == -1) {
			throw new StackEmpty();
		}
		topIndex--;
		return data[topIndex];
	}
	
	public int top() throws StackEmpty {
		if(topIndex == -1) {
			throw new StackEmpty();
		}
		return data[topIndex];
	}
	
	public int size() {
		return topIndex+1;
	}
	
	public boolean isEmpty() {
		return topIndex == -1;
	}
}
