package Stack;

public class StackEmpty extends Exception {

}
