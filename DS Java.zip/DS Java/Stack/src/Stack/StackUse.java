package Stack;

public class StackUse {

	public static void main(String[] args) throws StackFullException, StackEmpty {
//		StackAsArray stack = new StackAsArray();
//		stack.push(10);
//		stack.push(20);
//		stack.push(30);
//		System.out.println(stack.pop());
//		System.out.println(stack.top());
//		System.out.println(stack.size());
//		System.out.println(stack.isEmpty());
		StackAsLinkedList<Integer> stack = new StackAsLinkedList<>();
		int[] arr = {1,2,3,4,5};
		for(int i=0;i<arr.length;i++) {
			stack.push(arr[i]);
		}
		while(! stack.isEmpty()) {
			System.out.println(stack.pop());
		}
	}

}
