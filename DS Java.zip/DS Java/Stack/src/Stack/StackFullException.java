package Stack;

public class StackFullException extends Exception {

}
