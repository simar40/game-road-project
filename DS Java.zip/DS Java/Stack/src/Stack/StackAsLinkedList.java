package Stack;

public class StackAsLinkedList<T> {
	Node<T> head;
	int size;
	StackAsLinkedList(){
		head=null;
		size=0;
	}
	
	public void push(T n) {
		Node<T> newElem = new Node<T>(n);
		newElem.next=head;
		head=newElem;
		size++;
	}
	
	public T pop() throws StackEmpty {
		if(size==0) {
			throw new StackEmpty();
		}
		T temp=head.data;
		head=head.next;
		size--;
		return temp;
	}
	
	public T top() throws StackEmpty{
		if(size==0) {
			throw new StackEmpty();
		}
		return head.data;
	}
	
	public int size() {
		return size;
	}
	
	public boolean isEmpty() {
		return size==0;
	}
}
