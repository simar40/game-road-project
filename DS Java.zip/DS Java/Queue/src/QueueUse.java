
public class QueueUse {

	public static void main(String[] args) throws QueueEmptyException {
		QueueAsArray queue = new QueueAsArray();
		int[] arr = {10,20,30,40,50,60,70};
		for(int n : arr) {
			queue.enqueue(n);
		}
		while(!queue.isEmpty()) {
			System.out.print(queue.dequeue() + " ");
		}
	}

}
