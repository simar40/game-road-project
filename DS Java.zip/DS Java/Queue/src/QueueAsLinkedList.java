
public class QueueAsLinkedList<T> {
		//Define the data members
	    Node<T> head;
	    Node<T> rear;
	    int size;

		public QueueAsLinkedList() {
			//Implement the Constructor
		}
		


		/*----------------- Public Functions of Stack -----------------*/


		public int getSize() { 
			//Implement the getSize() function
	        return size;
	    }


	    public boolean isEmpty() { 
	    	//Implement the isEmpty() function
	        return size==0;
	    }


	    public void enqueue(T data) {
	    	//Implement the enqueue(element) function
	    	size++;
	        Node<T> newElem = new Node<T>(data);
	        if(head==null){
	            head=newElem;
	            rear=newElem;
	        }
	        else{
	            rear.next=newElem;
	     		rear=newElem;
	        }
	    }


	    public T dequeue() throws QueueEmptyException {
	    	//Implement the dequeue() function
	        if(head==null){
	            throw new QueueEmptyException();
	        }
	        T temp=head.data;
	        head=head.next;
	        if(head==null) {
	        	rear=null;
	        }
	        size--;
	        return temp;
	    }


	    public T front() throws QueueEmptyException {
	    	//Implement the front() function
	        if(head==null){
	            throw new QueueEmptyException();
	        }
	        return head.data;
	    }
	}
