
public class QueueEmptyException extends Exception {

}
