/*
Queue is abstract data type and it has is based on FIFO principle i.e. First In First Out.
New element added is added at the last. Element deleted is element at first.
Enqueue : Adds new element to queue
Dequeue : Deletes first element from queue
Front   : Reads first element of queue
*/

import java.util.Queue;
public class Basics {

	public static void main(String[] args) {
		
	}

}
