
public class QueueAsArray {
	private int[] data;
	private int size=0;
	private int front, rear;	//front is index of front element and rear is index of rear element
	public QueueAsArray(){
		data = new int[5];
		front=-1;
		rear=-1;
	}
	public QueueAsArray(int capacity) {
		data=new int[capacity];
		front=-1;
		rear=-1;
	}
	
//	ALL FUNCTIONS HAVE O(1) COMPLEXITY.
	
	public boolean isEmpty() {
		return size==0;
	}
	
	public int size() {
		return size;
	}
	
	public void enqueue(int elem) {
//		System.out.println(elem);
		if(size == data.length) {
			data = doubleArray(data);
//			System.out.println(rear);
//			System.out.println(data.length);
			rear = (rear + 1) % data.length; //1
			System.out.println(rear);
			data[rear]=elem;
			size++;
			for(int i=front;i<data.length;i++) {
				System.out.println("data::"+data[i]);
			}
		}
		if(size==0) {
			front=0;
			rear = (rear + 1) % data.length; //1
			data[rear]=elem;
			size++; //1
		}
//		rear++;
//		if(rear == data.length) {
//			rear=0;
//		}
//		Better way to write it is as follow
		else {
			rear = (rear + 1) % data.length; //1
			data[rear]=elem;
			size++; //1
		}
		
//		System.out.println(data[rear]);
	}
	
	private int[] doubleArray(int[] data) {
		System.out.println("data is called");
		int[] temp = data;
		data = new int[2*temp.length];
		int index=0;
		for(int i=front;i<temp.length;i++) {
//			System.out.println(temp[i]);
			data[index++]=temp[i];
//			System.out.println("data::"+data[i]);
		}
		return data;
		
//		System.out.println(data[4]);
//		for(int i=0;i<front-1;i++) {
//			data[index++]=temp[i];
//			System.out.println("data1::"+temp[1]);
//		}
//		front=0;
//		rear=temp.length-1;
	}
	public int dequeue() throws QueueEmptyException {
		if(size==0) {
			throw new QueueEmptyException();
		}
		int temp = data[front];
//		front++;
		front = (front + 1) % data.length;
		size--;
		if(size==0) {
			front = -1;
			rear = -1;
		}
		return temp;
	}
	
	public int front() throws QueueEmptyException {
		if(size==0) {
			throw new QueueEmptyException();
		}
		else {
			return data[front];
		}
	}
}
