/*
Data structure is a way of arranging or storing data. There are a lot of DS like arrays, 
ArrayLists, trees, hash maps, Linked List etc. These are used whenever needed.

Array List is kind of a dynamic array where we can add as many elements as we want without
before deciding the total size of the ArrayList. This is something that cannot be done in an
array. If we not specify the size, then it is itself initialized to size 10 and after 10
slots are filled, its size increases by 1.5 times the initial size.
*/

import java.util.ArrayList;
public class ListsInArray {

	public static void main(String[] args) {
//		ArrayList<Integer> arr=new ArrayList<>(20);
//		This will initialize arrayList to capacity of 20 elements, which can further be extended.
		ArrayList<Integer> arr=new ArrayList<>();
		arr.add(10);		//Adds element at 0th index
		arr.add(20);		//Adds element at 1st index
		arr.add(30);
		arr.add(85);
		arr.set(3, 69);		//Replaces element at 3rd index
		arr.remove(2);		//Removes element at 2nd index.	
		System.out.println(arr.size());
		arr.add(2,50);		//Adds element at 2nd index and shifts all other elements toward right
		System.out.println(arr.get(3));
		
		for(int i=0;i<arr.size();i++) {
			System.out.println(arr.get(i));
		}
		
//		Enhanced for loop
		for(int i : arr) {
			System.out.println(i);
		}
/*		In this enhanced for loop 'i' represents the element in arrayList and not the index.
		We read it out as for every element 'i' in arr....So here 'i' is element and this loop
		is used to print out all elements in arrayList and it is faster as compared to normal
		loop used above.
 
*/
	}
}