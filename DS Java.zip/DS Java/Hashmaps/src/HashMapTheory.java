/*HashMaps is used to store data in form of (key,value) form. 
Insert Delete Size Contains GetValue functions are of order O(1). Making it very fast.

In HashMaps the functions are very fast because the values are stored in an array. This array
is called bucket array and its size is almost the size of total elements. But index
values in array is integer so there is a hash function which takes key and converts it into
an integer. As integer value can be very large and bucket array will take a lot of space.
So a compression function is created to compress the integer value created by hash function.
Compression function performs '%' of size of bucket array. So all integer values created will
be of range 1 to size - 1. Then value and key both are stored at the integer index of array.

Bigger Integer created through hash function is called HashCode. It is created as follow : 
* If key value is integer then no change is made and same value is returned.
* If key value is String then ASCII value is multiplied by a prime number factor usually
  31 or 37 as follow :
  "abcd" = a*p^3 + b*p^2 + c*p + d*p^0.
  Then the value is compressed by '%' function. But in some cases due to small array size
  there is collision of two values at same index and that case is called collision case.

There are two ways to handle this collision case : 
1. Closed Hashing/Addressing : In closed hashing each index of array contains head of a linked
   list i.e. we create an array of linked list and in cases of collision all the colliding 
   values are stored in next of tail. This is also called separate chaining. 
   This is used in inbuilt HashMap function and is sufficient.

2. Open Hashing/Addressing : In this technique if the index is already occupied then it tries
   to find out some other index, which is dependent on the number of attempts we are making
   in finding the new index. It is written as following function : 
   HFi(a) = HF(a) + f(i); where 'i' is the number of attempts
   But here f(0) = 0 i.e. first we will check if the index is already empty or not.
   
   This can also be of many types like : 
   2.1. Linear probing : In this f(i) = i. This means we go to just next index to check and 
   so on.
   2.2. Quadratic probing : In this f(i) = i^2. So on there is cubic probing as well.
   2.3. Double hashing : In this f(i) = i * h'(a) where h'(a) is hash function that is self
   created or created through some other method.
   
*  LOAD FACTOR : It is the ratio of n/b. This is usually average number of elements present
                 in each index. Here, 
				 n = number of entries in HashMap
				 b = size of bucket array
				 This is maintained around 0.75 in normal cases so as to maintain time 
				 complexities of all functions as O(1). But if it crosses 0.75 value then we 
				 increase the size of bucket array by doubling its size. This is called
				 Rehashing.
*/
public class HashMapTheory {

}
