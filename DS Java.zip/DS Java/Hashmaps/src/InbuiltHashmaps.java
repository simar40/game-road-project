import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class InbuiltHashmaps {

	public static void main(String[] args) {
		HashMap<String,Integer> map = new HashMap<>();
		
		//Insert
		map.put("Raman", 98);
		map.put("Rahul", 67);
		
		//Prints entire map
		System.out.println(map);
		
		//size
		System.out.println(map.size());
		
		//contains
		if(map.containsKey("Raman")) {
			System.out.println("Map contains Raman");
		}
		if(map.containsKey("asd")) {
			System.out.println("Hello");
		}
		
		//get value
		int v = map.get("Raman");
		System.out.println(v);
		
		int v1 = 0;
		if(map.containsKey("abc")) {
			v1 = map.get("abc");
		}
		System.out.println(v1);
		
/*		int v2 = map.get("ad");
		This will give null pointer exception because ad is not present in map and v2 try to
		access the value at null address thus giving null pointer exception. So we must first
		check if String "ad" is present in map and if it is present then only assign value. 
*/
		//Remove
		map.remove("abc");		//This will not give any error
		
		map.put("Raman", 96);
//		This will reassign 96 value to Raman.
		
		//Iterating over key set
		Set<String> key = map.keySet();
		for(String s : key) {
			System.out.println(s);
		}
	}
}
