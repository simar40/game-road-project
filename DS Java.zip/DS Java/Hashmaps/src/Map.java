import java.util.ArrayList;

public class Map<K,V> {
	ArrayList<MapNode<K,V>> bucket;
	int count;
	int numBuckets;

	public Map(){
		numBuckets = 20;
		bucket = new ArrayList<>();
		for(int i=0;i<numBuckets;i++) {
			bucket.add(null);
		}
	}

	public int size() {
		return count;
	}

	public V getValue(K key) {
		int bucketIndex = getBucketIndex(key);
		MapNode<K,V> head = bucket.get(bucketIndex);

		while(head != null) {
			if(head.key.equals(key)) {
				return head.value;
			}
			head = head.next;
		}
		return null;
	}

	public V removeKey(K key) {
		int bucketIndex = getBucketIndex(key);
		MapNode<K,V> head = bucket.get(bucketIndex);
		MapNode<K,V> prev = null;

		while(head != null) {
			if(head.key.equals(key)) {
				if(prev != null) {
					prev.next = head.next;}
				else {
					bucket.set(bucketIndex, head.next);
				}
				count--;
				return head.value;
			}
			prev = head;
			head = head.next;
		}
		return null;
	}

	private int getBucketIndex(K key) {
		int hc = key.hashCode();
		return hc%numBuckets;
	}

	private void reHash() {
		ArrayList<MapNode<K, V>> temp = bucket;
		bucket = new ArrayList<>();
		for(int i=0;i<numBuckets*2;i++) {
			bucket.add(null);
		}
		count = 0;
		numBuckets = numBuckets*2;
		for(int i=0;i<temp.size();i++) {
			MapNode<K, V> head = temp.get(i);
			while(head != null) {
				K key = head.key;
				V value = head.value;
				insert(key,value);
				head = head.next;
			}
		}
	}
	
	public void insert(K key, V value) {
		int bucketIndex = getBucketIndex(key);
		MapNode<K,V> head = bucket.get(bucketIndex);

		//Check if element is already present?
		while(head != null) {
			if(head.key.equals(key)) {
				head.value = value;
				return;
			}
			head = head.next;
		}

		//If element is not present.
		head = bucket.get(bucketIndex);
		MapNode<K, V> newNode = new MapNode<>(key, value);
		newNode.next = head;
		bucket.set(bucketIndex, newNode);
		count++;
		
		double LoadFactor = 1*(count)/numBuckets;
		if(LoadFactor > 0.7) {
			reHash();
		}
	}
}
