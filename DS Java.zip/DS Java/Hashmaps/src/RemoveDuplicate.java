import java.util.ArrayList;
import java.util.HashMap;
public class RemoveDuplicate {

	public static ArrayList<Integer> removeDuplcate(int[] arr) {
		ArrayList<Integer> result = new ArrayList<>();
		HashMap<Integer,Boolean> map = new HashMap<>();
		for(int i=0;i<arr.length;i++) {
			if(map.containsKey(arr[i])) {
				continue;
			}
			result.add(arr[i]);
			map.put(arr[i], true);
		}
		return result;
	}
	
	public static void main(String[] args) {
		int[] arr = {1,2,3,3,5,6,2,7,8,7,9,8};
		ArrayList<Integer> output = removeDuplcate(arr);
		System.out.println(output);
	}
}
