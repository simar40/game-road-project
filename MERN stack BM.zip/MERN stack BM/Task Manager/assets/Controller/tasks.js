window.addEventListener("load",init);

function init()
{
    bindEvents();
    countUpdate();
}

function bindEvents()
{
    document.querySelector("#add").addEventListener("click",addTask);
}

function countUpdate()
{
    document.getElementById("total").innerText = taskOperations.getTotal();
}

function addTask()
{
    const fields = ["id","name","desc","date","url","pr"];
    const task = {};
    for(let field of fields)
    {
        task[field] = document.querySelector(`#${field}`).value;
    }
    taskOperations.add(task);
    countUpdate();
    printTask(task);
}

function printTask(task)
{
    let tbody = document.getElementById("tasks");
    let tr = tbody.insertRow();
    let index  = 0;
    for(let key in task)
    {
        tr.insertCell(index).innerText = task[key];
    }
}