const taskOperations = {
    tasks: [],
    getTotal() {
        return this.tasks.length;
    },
    add(task) {
        let taskObject = new Task(task.id, task.name, task.desc, task.date, task.url, task.pr);
        this.tasks.push(taskObject);
        return this.getTotal();
    },
    delete() { },
    search() { },
    update() { },
    sort() { },
}