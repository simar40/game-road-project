var box = document.getElementsByClassName("box");

const isNotBlank = (currBox) => currBox.innerText.length == 1;

const isEqual = (one,two,three) => (one.innerText == two.innerText) && (one.innerText == three.innerText);

const isSameRow = (one,two,three) =>
(isNotBlank(one) && isNotBlank(two) && isNotBlank(three) && isEqual(one,two,three))

let isOver = false;

function isGameOver()
{
    if(isSameRow(box[0],box[1],box[2])){
        isOver = true;
    }
    else if(isSameRow(box[3],box[4],box[5])){
        isOver = true;
    }
    else if(isSameRow(box[6],box[7],box[8])){
        isOver = true;
    }
    else if(isSameRow(box[0],box[3],box[6])){
        isOver = true;
    }
    else if(isSameRow(box[1],box[4],box[7])){
        isOver = true;
    }
    else if(isSameRow(box[2],box[5],box[8])){
        isOver = true;
    }
    else if(isSameRow(box[0],box[4],box[8])){
        isOver = true;
    }
    else if(isSameRow(box[2],box[4],box[6])){
        isOver = true;
    }
    return isOver;
}

function reset()
{
    cross = true;
    count = 0;
    document.getElementById('result').innerText = "";
    for(let b of box)
    {
        b.innerText = "";
        isOver = false;
    }
}

for (let i = 0; i < box.length; i++) {
    box[i].addEventListener("click", printXor0)
}

let cross = true;
let count = 0;

function printXor0 () {
    if (this.innerHTML == "" && !isOver) {
        count++;
        this.innerHTML = cross === true ? "X":"0";
        cross = !cross;
    }
    if(count == 9)
    {
        document.getElementById('result').innerText = "Game Draw";
        setTimeout(reset,4000);   
    }
    if(count>=5)
    {
        let isOver = isGameOver();
        if(isOver)
        {
            cross = !cross;
            let label = cross === true ? "X":"0";
            document.getElementById('result').innerText = `Game Over ${label} is winner!`;
            setTimeout(reset,4000);
        }
    }
}