let submit = document.getElementById("submit");
let reset = document.getElementById("reset");

submit.addEventListener("click",printResult);
function printResult()
{
    let result = document.getElementById("result");
    let first = document.getElementById("first").value;
    let last = document.getElementById("last").value;
    if((first != "" && last != "") || (first != ""))
    {
        result.innerText = "Welcome " + first + " " + last;
    }
}

reset.addEventListener("click",resetResult);
function resetResult()
{
    let result = document.getElementById("result").innerText = "";
    let first = document.getElementById("first").value = "";
    let last = document.getElementById("last").value = "";
}
